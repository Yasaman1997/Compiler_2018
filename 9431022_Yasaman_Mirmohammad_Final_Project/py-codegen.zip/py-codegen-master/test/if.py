#isko jama karna hai =D
a = 10
if a == 10:
	print 1
else :
	print 2
a = a*10
if a > 10:
	print 3
	if a > 15:
		print 4
		if a == 100:
			print 5
	else :
		print 6
else :
	print 7
b = a + a*2 + a/3 - a
print b 
print a + b 
if b > 200:
	print b * b