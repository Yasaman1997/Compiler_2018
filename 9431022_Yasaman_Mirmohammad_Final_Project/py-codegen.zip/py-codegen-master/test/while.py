a = 100
summ = 0
while a > 0:
	summ = summ + a
	a = a-1
print summ