def f():
	return 1

def f1():
	a = f()
	return 2*a

x = f1()
print x 
