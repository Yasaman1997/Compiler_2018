def myfun():
	a = 23
	return a*a


a = myfun()
print a