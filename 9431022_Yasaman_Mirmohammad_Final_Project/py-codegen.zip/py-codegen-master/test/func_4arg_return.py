def myfun(c, d, e, f):
	a = 35
	b = a + c
	return c+d+e+f
a = myfun(1000, 100, 10, 1)
print a

