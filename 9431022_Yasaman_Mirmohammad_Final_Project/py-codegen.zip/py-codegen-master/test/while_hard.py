a = 100
summ = 0
while a > 0:
	b = 40
	while b >= 0:
		summ = summ +b 
		b = b -1
	a = a - 2
print summ