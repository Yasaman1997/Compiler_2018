a = 10
b = 20
print a
print b
c = a + b
print c
b = a * c
print b
b = b*b
print b