import ply.yacc as yacc
from lexer.lexer import Lexer

class Parser:

    tokens = Lexer.tokens

    def p_program(self, p):
        '''program : PROGRAM_KW SHENASE declarations_list list_ravie MAIN block
                   | PROGRAM_KW SHENASE list_ravie MAIN block
                   | PROGRAM_KW SHENASE declarations_list MAIN block
                   | PROGRAM_KW SHENASE MAIN block'''

    def p_declarations_list(self, p):
        '''declarations_list : declarations
                             | declarations_list declarations'''

    def p_declarations(self, p):
        '''declarations : taeen_type declarator_list SEMICOLON'''

    def p_taeen_type(self, p):
        '''taeen_type : INTEGER_KW
                      | FLOAT_KW
                      | CHAR_KW
                      | BOOLEAN_KW'''

    def p_declarator_list(self, p):
        '''declarator_list : declarator
                           | declarator_list COMMA declarator'''

    def p_declarator(self, p):
        '''declarator :	dec
                      |	dec	EXP	meghdar_avalie'''

    def p_dec(self, p):
        '''dec : SHENASE
               | SHENASE OPENING_BRACKET range CLOSING_BRACKET
               | SHENASE OPENING_BRACKET ADADSABET CLOSING_BRACKET'''

    def p_range(self, p):
        '''range : SHENASE DOT DOT SHENASE
                 | ADADSABET DOT DOT ADADSABET
                 | ebarat_riazi DOT DOT ebarat_riazi'''

    def p_meghdar_avalie(self, p):
        '''meghdar_avalie : ebarat_sabet
                          | OPENING_BRACE list_meghdar_avalie CLOSING_BRACE'''

    def p_list_meghdar_avalie(self, p):
        '''list_meghdar_avalie : ebarat_sabet COMMA	list_meghdar_avalie
                               | ebarat_sabet'''

    def p_list_ravie(self, p):
        '''list_ravie : list_ravie ravie
                      | ravie'''

    def p_ravie(self, p):
        '''ravie : METHOD_KW SHENASE parameters	OPENING_BRACE declarations_list	block CLOSING_BRACE SEMICOLON
                 | METHOD_KW SHENASE parameters	OPENING_BRACE block CLOSING_BRACE SEMICOLON'''

    def p_parameters(self, p):
        '''parameters : OPENING_PARENTHESES declarations_list COSING_PARENTHESES
                      | OPENING_PARENTHESES COSING_PARENTHESES'''

    def p_block(self, p):
        '''block : OPENING_BRACE statement_list	CLOSING_BRACE'''

    def p_statement_list(self, p):
        '''statement_list : statement SEMICOLON
                          | SEMICOLON
                          | statement_list statement SEMICOLON
                          | statement_list SEMICOLON'''

    def p_statement(self, p):
        '''statement : SHENASE EXP ebarat
                     | IF_KW ebarat_bool THEN_KW statement ELSE_KW statement
                     | IF_KW ebarat_bool THEN_KW statement ELSE_KW
                     | IF_KW ebarat_bool THEN_KW ELSE_KW statement
                     | IF_KW ebarat_bool THEN_KW ELSE_KW
                     | DO_KW statement WHILE_KW ebarat_bool
                     | DO_KW WHILE_KW ebarat_bool
                     | FOR_KW SHENASE EXP counter DO_KW statement
                     | FOR_KW SHENASE EXP counter DO_KW
                     | SWITCH_KW ebarat onsor_mored default END_KW
                     | SWITCH_KW ebarat onsor_mored END_KW
                     | SHENASE OPENING_PARENTHESES arguments_list COSING_PARENTHESES
                     | SHENASE OPENING_PARENTHESES COSING_PARENTHESES
                     | SHENASE OPENING_BRACKET ebarat CLOSING_BRACKET EXP ebarat
                     | RETURN_KW ebarat
                     | EXIT_WHEN_1ST_KW EXIT_WHEN_2ND_KW ebarat_bool
                     | block'''

    def p_arguments_list(self, p):
        '''arguments_list : multi_arguments'''

    def p_multi_arguments(self, p):
        '''multi_arguments : multi_arguments COMMA ebarat
                           | ebarat'''

    def p_counter(self, p):
        '''counter : ADADSABET UPTO_KW ADADSABET
                   | ADADSABET DOWNTO_KW ADADSABET'''

    def p_onsor_mored(self, p):
        '''onsor_mored : CASE_KW ADADSABET COLON block
                       | onsor_mored CASE_KW ADADSABET COLON block'''

    def p_default(self, p):
        '''default : DEFAULT_KW COLON block'''

    def p_ebarat(self, p):
        '''ebarat : ebarat_sabet
                   | ebarat_bool
                   | ebarat_riazi
                   | SHENASE
                   | SHENASE OPENING_BRACKET ebarat CLOSING_BRACKET
                   | SHENASE OPENING_PARENTHESES arguments_list COSING_PARENTHESES
                   | SHENASE OPENING_PARENTHESES COSING_PARENTHESES
                   | OPENING_PARENTHESES ebarat COSING_PARENTHESES'''

    def p_ebarat_sabet(self, p):
        '''ebarat_sabet : ADADSABET
                        | REALCONST
                        | HARF
                        | BOOLSABET'''

    def p_ebarart_bool(self, p):
        '''ebarat_bool : zojmoratab AND_KW
                       | zojmoratab OR_KW
                       | zojmoratab AND_THEN_KW
                       | zojmoratab OR_NOT_KW
                       | zojmoratab LT
                       | zojmoratab LE
                       | zojmoratab G
                       | zojmoratab GE
                       | zojmoratab EQ
                       | zojmoratab NEQ
                       | ebarat NOT_KW'''

    def p_ebarat_riazi(self, p):
        '''ebarat_riazi : zojmoratab PLUS
                        | zojmoratab MINUS
                        | zojmoratab MUL
                        | zojmoratab DIV
                        | zojmoratab MOD
                        | MINUS ebarat'''

    def p_zojmoratab(self, p):
        '''zojmoratab : OPENING_PARENTHESES ebarat COMMA ebarat COSING_PARENTHESES'''

    def p_error(self, p):
        # print('syntax error')
        # exit(5)
        if p:
            print("Syntax error at token", p)
            # Just discard the token and tell the parser it's okay.
            # self.parser.errok()
            exit(5)
        else:
            print("Syntax error at EOF")

    def build(self, **kwargs):
        '''
        build the parser
        '''
        self.parser = yacc.yacc(module=self, **kwargs)
        return self.parser
