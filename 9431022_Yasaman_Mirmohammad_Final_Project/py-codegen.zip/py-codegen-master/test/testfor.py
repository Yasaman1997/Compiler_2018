for x in [1,2,3,4]:
	print x
	x = 4