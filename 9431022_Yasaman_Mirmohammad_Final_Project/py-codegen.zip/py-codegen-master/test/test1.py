for i in [1,2,3,4]:
	if i == 2:
		continue
	else:
		i = 3