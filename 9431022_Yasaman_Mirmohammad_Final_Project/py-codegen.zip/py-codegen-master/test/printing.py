a = 1
b = 2
print 2, a, 8*8, a*b/2