def f1(a):
	return 2

def f2(b):
	print b+1
a = [1,2,3,3]
x = f1(2)
print a[1]+x