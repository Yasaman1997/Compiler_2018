a = 100
b = 200
print b > a
print a > b
print b < a
print a < b
print a == a
print a != a
print a != b
print a == b