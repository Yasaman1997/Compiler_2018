def max(a, b):
	if a > b:
		return a
	else:
		return b

def min(a, b):
	if a < b:
		return a
	else:
		return b
