def myfun():
	return 2


myfun()