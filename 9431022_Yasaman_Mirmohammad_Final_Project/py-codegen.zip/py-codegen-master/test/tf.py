#isko jama karna hai 
a = 4 > 3
if a == 1 :
	print 8
c = 3 > 4
if c == 0 :
	print 9
if a or c :
	print 10
if a and c :
	print 11
if a and c or a or c :
	print 12