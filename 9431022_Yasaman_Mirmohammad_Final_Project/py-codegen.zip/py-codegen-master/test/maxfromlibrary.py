a = max(10, 5)
print a