a = 100
while a > 0:
	if a % 5 == 0:
		print a 
	if a%37 == 0:
		break
	a = a - 1
print a